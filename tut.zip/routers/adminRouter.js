const express = require('express');
const router = express.Router();
const adminActions = require('../controllers/adminController');

router.get('/admin', adminActions.adminPageController);
router.get('/admin/add-user', adminActions.getAddUser);

router.post('/add-user', adminActions.postAddUser);

router.get('/admin/user/:id', adminActions.getSingleUser)

module.exports = router