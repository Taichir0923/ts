const express = require('express')
const app = express();
const path = require('path');
const bp = require('body-parser');
const mongoose = require('mongoose');

const homeRouter = require('./routers/homeRouter');
const adminRouter = require('./routers/adminRouter');

app.set('view engine', 'ejs');
app.set('views', 'views');

app.use(bp.urlencoded({extended: false}));
app.use(express.static(path.join(__dirname, 'public')));

app.use(homeRouter);
app.use(adminRouter);

app.use((req, res) => {
    res.status(404).render('404');
})


mongoose.connect('mongodb+srv://narada:admin1234@cluster0.fyk5k.mongodb.net/mydb')
    .then(() => {
        app.listen(3000)
    })
    .catch(err => console.log(err));

// Model Views Controller